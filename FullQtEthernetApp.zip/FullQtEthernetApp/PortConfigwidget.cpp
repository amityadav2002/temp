#include "PortConfigWidget.h"
#include "ui_PortConfigWidget.h"

PortConfigWidget::PortConfigWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PortConfigWidget),
    socket(new QTcpSocket(this))
{
    ui->setupUi(this);

    connect(ui->btnconnect, &QPushButton::clicked, this, &PortConfigWidget::on_btnConnect_clicked);
    connect(ui->btnDisconnect, &QPushButton::clicked, this, &PortConfigWidget::on_btnDisconnect_clicked);

    connect(socket, &QTcpSocket::connected, this, [=]() {
        emit logMessage("✅ Connected successfully to host.");
    });

    connect(socket, &QTcpSocket::disconnected, this, [=]() {
        emit logMessage("🔌 Disconnected from host.");
    });

    connect(socket, &QTcpSocket::errorOccurred, this, [=](QAbstractSocket::SocketError) {
        emit logMessage("❌ Error: " + socket->errorString());
    });
}

PortConfigWidget::~PortConfigWidget()
{
    delete ui;
}

void PortConfigWidget::on_btnConnect_clicked()
{
    QString ip = ui->inputIP->text().trimmed();
    int port = ui->dropdownPort->currentText().toInt();

    socket->abort();  // Cancel any previous attempt
    socket->connectToHost(ip, port);

    emit logMessage("⏳ Connecting to " + ip + ":" + QString::number(port));
}

void PortConfigWidget::on_btnDisconnect_clicked()
{
    socket->disconnectFromHost();
    emit logMessage("Attempting to disconnect...");
}
