#ifndef PORTCONFIGWIDGET_H
#define PORTCONFIGWIDGET_H

#include <QWidget>
#include <QTcpSocket>

namespace Ui {
class PortConfigWidget;
}

class PortConfigWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PortConfigWidget(QWidget *parent = nullptr);
    ~PortConfigWidget();

signals:
    void logMessage(const QString &msg); // For printing in MainWindow terminal

private slots:
    void on_btnConnect_clicked();
    void on_btnDisconnect_clicked();

private:
    Ui::PortConfigWidget *ui;
    QTcpSocket *socket;
};

#endif // PORTCONFIGWIDGET_H
