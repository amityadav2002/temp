QT += core gui widgets network

TARGET = StyledQtApp
TEMPLATE = app

SOURCES += main.cpp \
           PortConfigwidget.cpp \
           mainwindow.cpp

HEADERS += mainwindow.h \
    PortConfigwidget.h
FORMS += mainwindow.ui \
    PortConfigWidget.ui
