#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QPushButton>
#include <QApplication>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    // Set initial theme
    applyTheme("Light Theme");
    // Theme selection handling
    connect(ui->themeSelector, &QComboBox::currentTextChanged, this, &MainWindow::onThemeChanged);

    // Set default page to home
    ui->stackedWidget->setCurrentWidget(ui->pageHome);
    ui->tabWidget->setCurrentIndex(0);

    // Functional button connections
    // Ethernet Config Buttons
    connect(ui->btnPortConfig, &QPushButton::clicked, this, &MainWindow::showPortConfig);
    //connect(ui->btnConnect, &QPushButton::clicked, this, &MainWindow::connectToEthernet);
    //connect(ui->btnDisconnect, &QPushButton::clicked, this, &MainWindow::disconnectEthernet);
    connect(ui->tabWidget, &QTabWidget::currentChanged, this, &MainWindow::onTabChanged);


    // EMI buttons
    connect(ui->btnEMIConnect, &QPushButton::clicked, this, &MainWindow::showPlaceholder);
    connect(ui->btnEMILog, &QPushButton::clicked, this, &MainWindow::showPlaceholder);
    connect(ui->btnEMIGenerate, &QPushButton::clicked, this, &MainWindow::showPlaceholder);

    // DBMS buttons
    connect(ui->btnDB1, &QPushButton::clicked, this, &MainWindow::showPlaceholder);
    connect(ui->btnDB2, &QPushButton::clicked, this, &MainWindow::showPlaceholder);
    connect(ui->btnDB3, &QPushButton::clicked, this, &MainWindow::showPlaceholder);
    connect(ui->btnDB4, &QPushButton::clicked, this, &MainWindow::showPlaceholder);

    // Utility buttons
    for (int i = 1; i <= 15; ++i) {
        QPushButton *btn = findChild<QPushButton *>(QString("btnUti%1").arg(i));
        if (btn)
            connect(btn, &QPushButton::clicked, this, &MainWindow::showPlaceholder);
    }

}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::onThemeChanged(const QString &theme) {
    applyTheme(theme);
}

void MainWindow::applyTheme(const QString &theme) {
    QFile file("style.qss");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Theme Error", "Failed to load style.qss");
        return;
    }

    QString baseStyle = file.readAll();
    file.close();

    if (theme == "Dark Theme") {
        QFile darkFile("dark_theme.qss");
        if (darkFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QString darkStyle = darkFile.readAll();
            baseStyle += "\n" + darkStyle;  // append dark theme on top
            darkFile.close();
        }
    }

    qApp->setStyleSheet(baseStyle);
}


void MainWindow::showPortConfig() {
    //ui->stackedWidget->setCurrentWidget(ui->pagePortConfig);
    portWidget = new PortConfigWidget(this);
    connect(portWidget, &PortConfigWidget::logMessage, this, &MainWindow::printToTerminal);
    ui->stackedWidget->addWidget(portWidget);
    ui->stackedWidget->setCurrentWidget(portWidget);
}

void MainWindow::showPlaceholder() {
    ui->stackedWidget->setCurrentWidget(ui->pagePlaceholder);
}

/*void MainWindow::connectToEthernet() {
    QString ip = ui->inputIP->text();
    int port = ui->dropdownPort->currentText().toInt();
    QMessageBox::information(this, "Ethernet", "Connecting to " + ip + ":" + QString::number(port));
}

void MainWindow::disconnectEthernet() {
    QMessageBox::information(this, "Ethernet", "Disconnected.");
}
*/
void MainWindow::onTabChanged(int index) {
    QString tabName = ui->tabWidget->tabText(index);

    if (tabName == "Home") {
        ui->stackedWidget->setCurrentWidget(ui->pageHome);
        // Optional: Reset pages
        //ui->inputIP->clear();
       // ui->dropdownPort->setCurrentIndex(0);
    }
}

void MainWindow::printToTerminal(const QString &message)
{
    qDebug()<< message;
}
