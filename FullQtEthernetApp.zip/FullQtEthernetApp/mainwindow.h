#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "PortConfigWidget.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onThemeChanged(const QString &theme);
    void showPortConfig();
    void showPlaceholder();
    //void connectToEthernet();
    //void disconnectEthernet();
    void onTabChanged(int index);
    void printToTerminal(const QString &message);



private:
    Ui::MainWindow *ui;
    void applyTheme(const QString &theme);
    PortConfigWidget *portWidget;

};

#endif // MAINWINDOW_H
