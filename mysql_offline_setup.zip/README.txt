MySQL Offline Setup Template

Steps:
1. Download mysql-8.x.x-winx64.zip from https://dev.mysql.com/downloads/mysql/
2. Extract it to C:\MySQL\mysql and copy this structure into it.
3. Run the following commands as administrator:
    cd C:\MySQL\mysql\bin
    mysqld --initialize
    mysqld --install MySQL
    net start MySQL
4. Log in and change root password.
